# Instructor Notes – Day 3 Lab 2

## Purpose

This lab is the final hands-on exercise in the curriculum. The submitted TOC states:

- Build a Docker image for a pre-built ML model
- Run the container
- Expose a REST API
- Invoke prediction requests
- Validate responses
- Review basic logging

The lab intentionally uses a pre-trained Iris classifier so participants do not spend time training a model from scratch.

## Recommended timing

- 10 min: explain inference vs training and architecture
- 10 min: local API inspection
- 10–15 min: Docker build/run
- 15 min: invoke and validate predictions
- 10 min: logging and healthcheck
- 10 min: non-root / hardened runtime
- 10 min: discussion / reflection

## Teaching architecture

```text
Pre-trained model artifact
        |
        v
Docker image
        |
        v
Container
        |
        v
REST inference API
        |
        v
Prediction + logs + health
```

## Important concept

Do not imply that this lab trains a production-ready ML system. It demonstrates the serving/deployment side of MLOps using a pre-built model artifact.

## Why the model is included

The model was trained once by the lab author from the standard Iris dataset and saved as a joblib artifact. Participants only consume the artifact. This is consistent with the TOC note to use a pre-trained sample model.

## Expected successful requests

Setosa:

```json
{
  "sepal_length": 5.1,
  "sepal_width": 3.5,
  "petal_length": 1.4,
  "petal_width": 0.2
}
```

Versicolor:

```json
{
  "sepal_length": 6.0,
  "sepal_width": 2.9,
  "petal_length": 4.5,
  "petal_width": 1.5
}
```

Virginica:

```json
{
  "sepal_length": 6.5,
  "sepal_width": 3.0,
  "petal_length": 5.2,
  "petal_width": 2.0
}
```

## Troubleshooting

### Port 8080 already in use

Use another host port:

```bash
docker run -d --name iris-ml-api -p 8090:8080 iris-ml-api:1.0
```

Then call:

```bash
curl http://127.0.0.1:8090/health
```

### Container exits immediately

Run:

```bash
docker ps -a
```

Then:

```bash
docker logs iris-ml-api
```

### Health is starting/unhealthy

Give the container a few seconds and inspect:

```bash
docker inspect --format='{{json .State.Health}}' iris-ml-api
```

### Prediction returns 400

Check:

- Content-Type is application/json
- all four feature names are present
- values are numeric and finite

### Docker build is very slow

The image includes scikit-learn and scientific Python dependencies. This is expected. Once downloaded, Docker's cache should make rebuilds much faster.

### Security-hardened container fails

Check logs first:

```bash
docker logs iris-ml-api
```

The service should not need to write to the image filesystem. The command creates a writable `/tmp` tmpfs for compatibility.

## Key discussion points

### Model vs API

The model is the decision component. The Flask/Gunicorn service is the delivery mechanism that accepts input and invokes the model.

### Training vs inference

Training learns parameters from data. Inference applies an already-trained model to new input.

### Model versioning

The model version in the API response demonstrates that serving systems need a way to identify which model artifact is currently producing predictions.

### Logging

The service logs model name/version/class, not the full request payload. Use this to start a discussion about privacy, sensitive data and logging minimization.

### Container security

The Dockerfile runs as UID/GID 10001. The optional hardened runtime adds:

```text
--read-only
--tmpfs /tmp
--cap-drop=ALL
--security-opt=no-new-privileges:true
```

The goal is to show that runtime restrictions should be tailored to what the application actually needs.

## Bridge to the course

This lab connects the earlier modules as follows:

```text
Day 1
Container images / secure CI-CD
        |
        v
Day 2
API security / threat modeling
        |
        v
Day 3
ML model + inference API + container deployment
```

A strong closing question is:

> “We have a working ML inference API. What threats would you model before putting it on the Internet?”

Likely discussion areas:

- unauthenticated prediction access
- excessive request volume / resource exhaustion
- malicious or malformed input
- model theft
- sensitive training or inference data exposure
- dependency/image vulnerabilities
- model artifact tampering
- overly verbose logs
- weak network controls
- authorization gaps

Do not present this as a complete production security assessment; use it to transition into risk assessment and audit concepts.
