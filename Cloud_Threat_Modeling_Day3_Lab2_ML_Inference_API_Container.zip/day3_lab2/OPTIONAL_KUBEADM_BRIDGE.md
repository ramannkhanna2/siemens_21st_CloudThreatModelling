# Optional Kubeadm Bridge

This extension is optional. The core lab is intentionally container-only, matching the curriculum item “Deploy an ML Inference API in a Container”.

Use this only after the Docker-based lab is complete and the participant has access to a kubeadm cluster.

## 1. Save the image

On the machine where the image was built:

```bash
docker save iris-ml-api:1.0 -o iris-ml-api-1.0.tar
```

Copy the tar file to a Kubernetes worker node.

## 2. Import into containerd

On the worker node, if the cluster uses containerd:

```bash
sudo ctr -n k8s.io images import iris-ml-api-1.0.tar
```

Verify:

```bash
sudo ctr -n k8s.io images list | grep iris-ml-api
```

Your environment may instead use `crictl` or another approved image-import workflow. Use the runtime-native procedure for the cluster.

## 3. Run the image in Kubernetes

The image can then be referenced by a Pod/Deployment using:

```yaml
image: iris-ml-api:1.0
imagePullPolicy: IfNotPresent
```

## 4. Port-forward

For a Deployment named `iris-ml-api` and Service named `iris-ml-api`:

```bash
kubectl port-forward service/iris-ml-api 8080:8080
```

Then invoke the same REST endpoints from the core lab.

This bridge is deliberately not part of the participant's required path because the submitted TOC defines Lab 2 around container deployment rather than another Kubernetes deployment exercise.
