import json
import logging
import os
from pathlib import Path

import joblib
import numpy as np
from flask import Flask, jsonify, request

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model" / "iris_model.joblib"
METADATA_PATH = BASE_DIR / "model" / "metadata.json"

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger("ml-inference-api")

MAX_BODY_BYTES = 16 * 1024
MODEL = joblib.load(MODEL_PATH)
with METADATA_PATH.open("r", encoding="utf-8") as f:
    MODEL_METADATA = json.load(f)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_BODY_BYTES

FEATURES = [
    "sepal_length",
    "sepal_width",
    "petal_length",
    "petal_width",
]


def validate_payload(payload):
    if not isinstance(payload, dict):
        raise ValueError("JSON body must be an object")

    missing = [feature for feature in FEATURES if feature not in payload]
    if missing:
        raise ValueError(f"Missing features: {', '.join(missing)}")

    values = []
    for feature in FEATURES:
        value = payload[feature]
        if isinstance(value, bool):
            raise ValueError(f"{feature} must be numeric")
        try:
            numeric_value = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{feature} must be numeric") from None
        if not np.isfinite(numeric_value):
            raise ValueError(f"{feature} must be finite")
        values.append(numeric_value)

    return values


@app.get("/health")
def health():
    return jsonify(
        status="ok",
        model_loaded=True,
        model_version=MODEL_METADATA["model_version"],
    )


@app.get("/info")
def info():
    return jsonify(
        service="iris-ml-inference-api",
        model_name=MODEL_METADATA["model_name"],
        model_version=MODEL_METADATA["model_version"],
        features=FEATURES,
        classes=MODEL_METADATA["classes"],
    )


@app.post("/predict")
def predict():
    if not request.is_json:
        return jsonify(error="Content-Type must be application/json"), 415

    payload = request.get_json(silent=True)
    try:
        values = validate_payload(payload)
    except ValueError as exc:
        logger.warning("prediction_rejected reason=%s", str(exc))
        return jsonify(error=str(exc)), 400

    prediction_index = int(MODEL.predict([values])[0])
    prediction_name = MODEL_METADATA["classes"][prediction_index]

    probabilities = MODEL.predict_proba([values])[0]
    probability_map = {
        MODEL_METADATA["classes"][index]: round(float(probability), 6)
        for index, probability in enumerate(probabilities)
    }

    logger.info(
        "prediction_completed model=%s version=%s class=%s",
        MODEL_METADATA["model_name"],
        MODEL_METADATA["model_version"],
        prediction_name,
    )

    return jsonify(
        model_name=MODEL_METADATA["model_name"],
        model_version=MODEL_METADATA["model_version"],
        prediction=prediction_name,
        probabilities=probability_map,
    )


@app.errorhandler(413)
def payload_too_large(_error):
    return jsonify(error="request_too_large"), 413


@app.errorhandler(404)
def not_found(_error):
    return jsonify(error="not_found"), 404


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8080"))
    app.run(host="0.0.0.0", port=port)
