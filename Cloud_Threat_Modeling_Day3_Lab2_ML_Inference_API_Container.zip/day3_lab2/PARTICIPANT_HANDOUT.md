# DAY 3 – HANDS-ON LAB 2
## Deploy an ML Inference API in a Container

**Duration:** 60–90 minutes  
**Difficulty:** Intermediate  
**Environment:** Docker Engine or Docker Desktop  
**Goal:** Build and run a containerized ML inference service using a pre-trained model.

---

## 1. What you will build

```text
Client
  |
  | HTTP POST /predict
  v
+---------------------------+
| Docker Container          |
|                           |
| Flask + Gunicorn API      |
|          |                |
|          v                |
| Pre-trained Iris Model    |
+---------------------------+
  |
  v
JSON prediction response
```

The model is already trained. Your job is to **package, deploy, invoke and validate** the inference service.

This directly covers the course requirement to build a Docker image for a pre-built ML model, run the container, expose a REST API, invoke prediction requests, validate responses and review basic logging.

---

# Part A – Prerequisites

### Step 1 – Verify Docker

Run:

```bash
docker --version
```

Then:

```bash
docker info
```

You should not receive a daemon connection error.

If Docker Desktop is installed, make sure it is running.

> You do **not** need the kubeadm cluster for the core of this lab. This lab is intentionally container-focused.

---

# Part B – Get the lab files

### Step 2 – Extract the starter ZIP

Extract the provided lab ZIP and enter the directory:

```text
day3_lab2/
```

You should see:

```text
day3_lab2/
├── app.py
├── requirements.txt
├── Dockerfile
├── .dockerignore
├── model/
│   ├── iris_model.joblib
│   └── metadata.json
└── tests/
    └── test_app.py
```

### Step 3 – Understand the model artifact

Open:

```text
model/metadata.json
```

You will see:

```json
{
  "model_name": "iris-logistic-regression",
  "model_version": "iris-logreg-v1",
  "classes": ["setosa", "versicolor", "virginica"],
  "features": [
    "sepal_length",
    "sepal_width",
    "petal_length",
    "petal_width"
  ]
}
```

The `.joblib` file is the actual pre-trained model artifact.

You are **not** going to train it.

Think about the MLOps flow:

```text
Training
   |
   v
Model artifact
   |
   v
Model version
   |
   v
Inference service
   |
   v
REST API
```

---

# Part C – Run the API locally (optional but recommended)

This step lets you understand the application before containerization.

### Step 4 – Create a Python virtual environment

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Install dependencies:

```bash
python -m pip install -r requirements.txt
```

### Step 5 – Start the API locally

```bash
python app.py
```

The application listens on:

```text
http://127.0.0.1:8080
```

Keep that terminal open.

In another terminal, test:

```bash
curl http://127.0.0.1:8080/health
```

Expected:

```json
{
  "model_loaded": true,
  "model_version": "iris-logreg-v1",
  "status": "ok"
}
```

Then:

```bash
curl http://127.0.0.1:8080/info
```

You should see the model name, version, supported features and classes.

Stop the local server with `Ctrl+C`.

---

# Part D – Build the Docker image

### Step 6 – Build

From the `day3_lab2` directory:

```bash
docker build -t iris-ml-api:1.0 .
```

The command should finish successfully.

Verify:

```bash
docker images | grep iris-ml-api
```

Expected image:

```text
iris-ml-api   1.0
```

### What just happened?

The Dockerfile:

```text
Base Python image
      |
      v
Install dependencies
      |
      v
Copy API code
      |
      v
Copy pre-trained model
      |
      v
Create non-root user
      |
      v
Start Gunicorn
```

The model is packaged **inside the immutable image artifact** for this training scenario.

Docker's documentation recommends using a non-root `USER` when a service can run without privileges. citeturn824258search1turn824258search4

---

# Part E – Run the container

### Step 7 – Start the container

```bash
docker run -d --name iris-ml-api -p 8080:8080 iris-ml-api:1.0
```

Verify:

```bash
docker ps
```

You should see:

```text
iris-ml-api
```

### Step 8 – Verify the container logs

```bash
docker logs iris-ml-api
```

You should see Gunicorn startup messages and worker processes.

---

# Part F – Health check

### Step 9 – Test the health endpoint

```bash
curl http://127.0.0.1:8080/health
```

Expected:

```json
{
  "model_loaded": true,
  "model_version": "iris-logreg-v1",
  "status": "ok"
}
```

Check Docker's health status:

```bash
docker ps
```

After the healthcheck has had time to run, inspect:

```bash
docker inspect --format='{{json .State.Health}}' iris-ml-api
```

Look for:

```text
"Status":"healthy"
```

Docker supports `HEALTHCHECK` so a running container can have a separate health state from merely being a running process. citeturn824258search4

---

# Part G – Understand the API

The API exposes:

```text
GET  /health
GET  /info
POST /predict
```

### Step 10 – View API information

```bash
curl http://127.0.0.1:8080/info
```

The four input features are:

```text
sepal_length
sepal_width
petal_length
petal_width
```

The model predicts one of:

```text
setosa
versicolor
virginica
```

---

# Part H – Invoke the ML inference API

### Step 11 – Send a prediction request

Run:

```bash
curl -X POST http://127.0.0.1:8080/predict \
  -H "Content-Type: application/json" \
  -d '{
    "sepal_length": 5.1,
    "sepal_width": 3.5,
    "petal_length": 1.4,
    "petal_width": 0.2
  }'
```

Expected prediction:

```text
setosa
```

The response will also contain probabilities.

Example structure:

```json
{
  "model_name": "iris-logistic-regression",
  "model_version": "iris-logreg-v1",
  "prediction": "setosa",
  "probabilities": {
    "setosa": 0.99,
    "versicolor": 0.01,
    "virginica": 0.0
  }
}
```

The exact probability values may vary slightly with numerical precision; focus on the predicted class and response structure.

---

# Part I – Try more predictions

### Step 12 – Versicolor example

```bash
curl -X POST http://127.0.0.1:8080/predict \
  -H "Content-Type: application/json" \
  -d '{
    "sepal_length": 6.0,
    "sepal_width": 2.9,
    "petal_length": 4.5,
    "petal_width": 1.5
  }'
```

Expected prediction:

```text
versicolor
```

### Step 13 – Virginica example

```bash
curl -X POST http://127.0.0.1:8080/predict \
  -H "Content-Type: application/json" \
  -d '{
    "sepal_length": 6.5,
    "sepal_width": 3.0,
    "petal_length": 5.2,
    "petal_width": 2.0
  }'
```

Expected prediction:

```text
virginica
```

---

# Part J – Validate API behavior

This part is important. Do not test only successful requests.

## Step 14 – Missing feature

Try:

```bash
curl -i -X POST http://127.0.0.1:8080/predict \
  -H "Content-Type: application/json" \
  -d '{
    "sepal_length": 5.1,
    "sepal_width": 3.5,
    "petal_length": 1.4
  }'
```

Expected:

```text
HTTP/1.1 400
```

and an error describing the missing feature.

## Step 15 – Wrong content type

Run:

```bash
curl -i -X POST http://127.0.0.1:8080/predict \
  -d 'hello'
```

Expected:

```text
HTTP/1.1 415
```

The API requires:

```text
Content-Type: application/json
```

## Step 16 – Unknown endpoint

```bash
curl -i http://127.0.0.1:8080/does-not-exist
```

Expected:

```text
HTTP/1.1 404
```

---

# Part K – Review basic ML service logging

### Step 17 – Generate another prediction

```bash
curl -X POST http://127.0.0.1:8080/predict \
  -H "Content-Type: application/json" \
  -d '{
    "sepal_length": 6.5,
    "sepal_width": 3.0,
    "petal_length": 5.2,
    "petal_width": 2.0
  }'
```

Now inspect:

```bash
docker logs --tail 20 iris-ml-api
```

Look for the application log indicating a prediction completed.

The service logs the **model name, model version and predicted class**.

It deliberately does not log the full request payload.

Ask yourself:

> Why might logging every input to an ML API become a privacy or security problem in a real application?

---

# Part L – Inspect the container identity

### Step 18 – Check which user is running the application

Run:

```bash
docker exec iris-ml-api id
```

You should see UID/GID `10001` rather than UID `0`.

This means the application process is not running as root.

The Dockerfile uses the `USER` instruction for this purpose. Docker documents that `USER` determines the default user used for subsequent Dockerfile operations and runtime execution. citeturn824258search4

---

# Part M – Run with stronger runtime restrictions

The image already uses a non-root user. Now add runtime restrictions.

### Step 19 – Stop and remove the current container

```bash
docker rm -f iris-ml-api
```

### Step 20 – Run hardened

```bash
docker run -d \
  --name iris-ml-api \
  -p 8080:8080 \
  --read-only \
  --tmpfs /tmp:rw,size=16m \
  --cap-drop=ALL \
  --security-opt=no-new-privileges:true \
  iris-ml-api:1.0
```

Check:

```bash
docker ps
```

Then:

```bash
curl http://127.0.0.1:8080/health
```

Then test prediction again.

If the API still works, you have demonstrated that it does not require a writable root filesystem or extra Linux capabilities for this simple workload.

Docker and Kubernetes documentation both describe non-root execution and restrictive runtime/security contexts as useful application hardening controls. citeturn824258search1turn824258search2turn824258search3

---

# Part N – Inspect the final container

### Step 21 – Inspect configuration

```bash
docker inspect iris-ml-api
```

Find these values:

```text
Image
User
Exposed/Published ports
Healthcheck
ReadonlyRootfs
```

### Step 22 – Inspect image size

```bash
docker images iris-ml-api:1.0
```

Discuss:

> What dependencies are actually required to serve the model?

> What software could be removed from a production image?

> How would you scan this image before deployment?

Kubernetes' security checklist recommends minimizing image contents, using unprivileged users, and regularly scanning images and patching known vulnerable software. citeturn824258search10

---

# Part O – Optional security challenge

Complete this only after the core lab is working.

### Challenge 1 – Change the model version

Edit:

```text
model/metadata.json
```

Change:

```json
"model_version": "iris-logreg-v1"
```

to:

```json
"model_version": "iris-logreg-v2"
```

Rebuild:

```bash
docker build -t iris-ml-api:2.0 .
```

Run:

```bash
docker rm -f iris-ml-api
```

```bash
docker run -d \
  --name iris-ml-api \
  -p 8080:8080 \
  iris-ml-api:2.0
```

Check:

```bash
curl http://127.0.0.1:8080/health
```

Question:

> What does the model version tell a monitoring/MLOps system?

Expected idea:

```text
Which model artifact is serving predictions right now?
```

---

# Part P – Optional image scanning

If your environment already has Docker Scout enabled, inspect the image with:

```bash
docker scout quickview iris-ml-api:1.0
```

or use your organization's approved container scanner.

The goal is to connect this lab back to the Day 1 concept of **container image scanning**.

Do not treat a clean scanner report as proof that the ML workload is secure. Image scanning cannot establish that the model's predictions, authorization model, API logic, data handling or business rules are secure.

---

# Part Q – Cleanup

Stop and remove the container:

```bash
docker rm -f iris-ml-api
```

Optionally remove the image:

```bash
docker rmi iris-ml-api:1.0
```

If you also created version 2.0:

```bash
docker rmi iris-ml-api:2.0
```

---

# Final architecture

By the end of the lab you should understand:

```text
Pre-trained Model
      |
      v
Model Artifact
      |
      v
Docker Image
      |
      v
Container
      |
      v
Gunicorn / Flask
      |
      v
REST /predict endpoint
      |
      v
Prediction
      |
      v
Logs + Health Status
```

---

# Lab completion checklist

Mark each item when complete.

```text
[ ] Docker environment verified
[ ] Pre-trained model artifact identified
[ ] Application tested locally
[ ] Docker image built
[ ] Container started
[ ] /health verified
[ ] /info verified
[ ] /predict invoked successfully
[ ] Multiple predictions tested
[ ] Invalid request tested
[ ] Basic logs reviewed
[ ] Container runs as non-root
[ ] Hardened runtime tested
[ ] Container inspected
[ ] Cleanup completed
```

---

# Reflection questions

1. What is the difference between **model training** and **model inference**?

2. Why is the model artifact treated as a deployment artifact in this lab?

3. Why should the API validate incoming input before passing it to the model?

4. Why is model versioning useful in MLOps?

5. Why should an ML API avoid unnecessarily logging complete request payloads?

6. What is the security benefit of running the container as a non-root user?

7. What additional controls would be required before exposing this API to real users?

---

## Expected final result

```text
Docker Image
    |
    v
Container: iris-ml-api
    |
    +---- Health: OK
    |
    +---- Model: iris-logistic-regression
    |
    +---- Version: iris-logreg-v1
    |
    +---- REST API: /predict
    |
    +---- Prediction: setosa / versicolor / virginica
    |
    +---- Logs: prediction events
    |
    +---- Non-root execution
```
