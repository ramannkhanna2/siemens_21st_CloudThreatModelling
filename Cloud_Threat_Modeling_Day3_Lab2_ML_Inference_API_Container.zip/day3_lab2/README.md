# Day 3 – Lab 2: Deploy an ML Inference API in a Container

Training: Cloud Threat Modeling & Secure Cloud AI Workloads

## Lab objective

Build a Docker container around a **pre-trained** Iris classification model, expose it as a REST API, send prediction requests, validate responses, inspect basic logs, and review a few container security controls.

Participants do not train the model from scratch. A pre-trained `joblib` model artifact is already included in `model/`.

## Required environment

- Docker Engine or Docker Desktop
- Terminal / PowerShell
- curl (or another HTTP client)
- Internet access for the base image and Python package downloads during `docker build`

## Core path

1. Inspect the application and pre-trained model artifact.
2. Build the Docker image.
3. Run the container and expose port 8080.
4. Verify `/health` and `/info`.
5. Send prediction requests to `/predict`.
6. Test invalid requests and validate HTTP responses.
7. Review container logs.
8. Inspect image/container configuration.
9. Re-run using stronger runtime restrictions.
10. Clean up.

## Security notes

This is a training image, not a production ML service. It demonstrates useful baseline controls such as non-root execution, bounded request size, a healthcheck and a small dependency footprint. Participants should still understand that an ML API needs additional production controls such as authentication/authorization, network restrictions, image scanning, dependency management, provenance/signing, secrets management, model integrity controls and monitoring.
