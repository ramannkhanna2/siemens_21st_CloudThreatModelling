# Day 3 Hands-on Lab 1
## Deploy a Secure Application on an Existing kubeadm Kubernetes Cluster



---

## 1. Lab objectives

By the end of this lab, you will have:

- verified access to an existing kubeadm Kubernetes cluster
- deployed an application using a Kubernetes Deployment
- configured a ConfigMap
- configured a Secret
- created a Service
- applied a dedicated ServiceAccount and RBAC policy
- verified least-privilege permissions
- verified the application and its security settings

---

# Part A — Verify the existing kubeadm cluster

### Step 1 — Check the current kubectl context

Run:

```bash
kubectl config current-context
```

You should see the context assigned to your training cluster.

### Step 2 — Check Kubernetes API access

```bash
kubectl cluster-info
```

You should receive Kubernetes control-plane/service information.

### Step 3 — Check nodes

```bash
kubectl get nodes -o wide
```

Expected pattern:

```text
NAME            STATUS   ROLES           ...
control-plane   Ready    control-plane   ...
worker-1        Ready    <none>          ...
worker-2        Ready    <none>          ...
```

Your names will be different.

If the nodes that can run workloads are not `Ready`, stop here and contact the instructor. Do not modify the kubeadm cluster as part of this lab.

### Step 4 — Optional cluster health check

```bash
kubectl get pods -A
```

You do not need to fix unrelated cluster components for this lab. You only need a worker capable of scheduling your workload.

---

# Part B — Understand the application you are going to deploy

This lab uses the NGINX Inc. unprivileged image:

```text
nginxinc/nginx-unprivileged:1.31-alpine3.24
```

The image is intended to run NGINX as an unprivileged user and uses port `8080` rather than privileged port `80`.

The lab therefore does not require you to build or push a custom container image.

The application will be exposed internally through a Kubernetes `ClusterIP` Service. You will use `kubectl port-forward` to test it from your own machine.

---

# Part C — Create the namespace

### Step 5 — Create the lab namespace

```bash
kubectl apply -f k8s/00-namespace.yaml
```

Expected:

```text
namespace/cloudorders created
```

Verify:

```bash
kubectl get namespace cloudorders --show-labels
```

The namespace has Pod Security labels configured for the lab.

---

# Part D — Configure the application with ConfigMap

### Step 6 — Apply the ConfigMap

```bash
kubectl apply -f k8s/01-configmap.yaml
```

Verify:

```bash
kubectl get configmap -n cloudorders
```

Inspect:

```bash
kubectl describe configmap cloudorders-config -n cloudorders
```

The ConfigMap contains non-confidential configuration such as:

```text
APP_ENV
APP_MESSAGE
```

Important:

> ConfigMap is for non-confidential configuration. Do not use it for passwords, API keys, tokens, or other sensitive values.

---

# Part E — Configure the Secret

### Step 7 — Apply the Secret

```bash
kubectl apply -f k8s/02-secret.yaml
```

Verify only the metadata:

```bash
kubectl get secret cloudorders-secret -n cloudorders
```

Do NOT print the Secret value.

The Secret contains a fake training-only value named:

```text
DEMO_API_KEY
```

The workload will receive this Secret as a file mounted into the container.

---

# Part F — Create a dedicated ServiceAccount

### Step 8 — Create the ServiceAccount

```bash
kubectl apply -f k8s/03-serviceaccount.yaml
```

Verify:

```bash
kubectl get serviceaccount -n cloudorders
```

You should see:

```text
cloudorders-app
```

The manifest deliberately disables ServiceAccount token automounting because the application does not need to call the Kubernetes API.

---

# Part G — Apply RBAC

### Step 9 — Create the Role

```bash
kubectl apply -f k8s/04-role.yaml
```

Inspect:

```bash
kubectl describe role cloudorders-observer -n cloudorders
```

The Role grants only:

```text
get Pods
list Pods
```

It does not grant permission to create Deployments or read Secrets.

### Step 10 — Bind the Role to the ServiceAccount

```bash
kubectl apply -f k8s/05-rolebinding.yaml
```

Verify:

```bash
kubectl get rolebinding -n cloudorders
```

Conceptually:

```text
ServiceAccount
      |
      v
 RoleBinding
      |
      v
    Role
      |
      +---- get pods
      +---- list pods
```

---

# Part H — Deploy the application

### Step 11 — Apply the Deployment

```bash
kubectl apply -f k8s/06-deployment.yaml
```

Verify the Deployment:

```bash
kubectl get deployment -n cloudorders
```

Verify Pods:

```bash
kubectl get pods -n cloudorders -o wide
```

You should eventually see two Pods in `Running` state and `1/1` ready.

### Step 12 — Wait for rollout completion

```bash
kubectl rollout status deployment/cloudorders -n cloudorders
```

Expected:

```text
deployment "cloudorders" successfully rolled out
```

---

# Part I — Create the Service

### Step 13 — Apply the Service

```bash
kubectl apply -f k8s/07-service.yaml
```

Verify:

```bash
kubectl get service -n cloudorders
```

Expected pattern:

```text
NAME          TYPE        CLUSTER-IP    PORT(S)
cloudorders   ClusterIP   10.x.x.x      80/TCP
```

The Service sends traffic to Pods listening on port `8080`.

Architecture:

```text
Client
  |
  | port 80
  v
ClusterIP Service
  |
  | targetPort 8080
  v
Pod
  |
  v
NGINX :8080
```

---

# Part J — Test the application

### Step 14 — Port-forward the Service

Run:

```bash
kubectl port-forward -n cloudorders service/cloudorders 8080:80
```

Keep this terminal running.

Open a second terminal and run:

```bash
curl http://127.0.0.1:8080/
```

You should receive the training web page HTML.

You can also open this URL in a browser:

```text
http://127.0.0.1:8080/
```

Kubernetes `kubectl port-forward` supports forwarding a local port to a Service target port.

---

# Part K — Verify the ConfigMap is available to the Pod

### Step 15 — Find a Pod

```bash
kubectl get pods -n cloudorders
```

Copy one Pod name.

### Step 16 — Check the non-secret environment variables

```bash
kubectl exec -n cloudorders <POD_NAME> -- sh -c 'echo APP_ENV=$APP_ENV; echo APP_MESSAGE="$APP_MESSAGE"'
```

Expected pattern:

```text
APP_ENV=training
APP_MESSAGE=Secure Kubernetes application is running
```

---

# Part L — Verify the Secret without exposing its value

### Step 17 — Confirm the Secret file exists

```bash
kubectl exec -n cloudorders <POD_NAME> -- sh -c 'test -s /etc/cloudorders-secret/DEMO_API_KEY && echo DEMO_API_KEY=CONFIGURED'
```

Expected:

```text
DEMO_API_KEY=CONFIGURED
```

Do NOT run a command that prints the Secret value.

The learning point is:

```text
Secret exists
      !=
Secret should be exposed
```

---

# Part M — Verify RBAC / Least Privilege

### Step 18 — Can the workload identity read Pods?

```bash
kubectl auth can-i get pods \
  --as=system:serviceaccount:cloudorders:cloudorders-app \
  -n cloudorders
```

Expected:

```text
yes
```

### Step 19 — Can it list Pods?

```bash
kubectl auth can-i list pods \
  --as=system:serviceaccount:cloudorders:cloudorders-app \
  -n cloudorders
```

Expected:

```text
yes
```

### Step 20 — Can it create Deployments?

```bash
kubectl auth can-i create deployments.apps \
  --as=system:serviceaccount:cloudorders:cloudorders-app \
  -n cloudorders
```

Expected:

```text
no
```

### Step 21 — Can it read Secrets?

```bash
kubectl auth can-i get secrets \
  --as=system:serviceaccount:cloudorders:cloudorders-app \
  -n cloudorders
```

Expected:

```text
no
```

You have now demonstrated least privilege rather than simply talking about it.

---

# Part N — Verify container security settings

### Step 22 — Inspect the Pod securityContext

Run:

```bash
kubectl get pod -n cloudorders -l app=cloudorders -o yaml
```

Look for these settings:

```yaml
runAsNonRoot: true
```

```yaml
allowPrivilegeEscalation: false
```

```yaml
readOnlyRootFilesystem: true
```

```yaml
capabilities:
  drop:
    - ALL
```

```yaml
seccompProfile:
  type: RuntimeDefault
```

These settings are part of the lab's secure-by-default workload configuration.

---

# Part O — Verify replicas and self-healing

### Step 23 — Check replicas

```bash
kubectl get deployment cloudorders -n cloudorders
```

Expected:

```text
READY   UP-TO-DATE   AVAILABLE
2/2     2            2
```

### Step 24 — Delete one Pod

Find a Pod:

```bash
kubectl get pods -n cloudorders
```

Delete one:

```bash
kubectl delete pod <POD_NAME> -n cloudorders
```

Immediately check:

```bash
kubectl get pods -n cloudorders -w
```

A replacement Pod should be created by the Deployment/ReplicaSet.

Press `Ctrl+C` to stop watching.

This demonstrates the separation between the desired state and individual Pod instances.

---

# Part P — Final verification

Run:

```bash
kubectl get all -n cloudorders
```

Then:

```bash
kubectl get configmap,secret,serviceaccount,role,rolebinding -n cloudorders
```

You should be able to identify:

```text
Namespace
  |
  +-- Deployment
  |     |
  |     +-- ReplicaSet
  |            |
  |            +-- Pod
  |            +-- Pod
  |
  +-- Service
  |
  +-- ConfigMap
  |
  +-- Secret
  |
  +-- ServiceAccount
  |
  +-- Role
  |
  +-- RoleBinding
```

---

# Part Q — Questions to answer before finishing

### Question 1
Why is the ConfigMap appropriate for `APP_ENV` but not for `DEMO_API_KEY`?

### Question 2
Why does the workload use a dedicated ServiceAccount?

### Question 3
What would be the security impact of giving this ServiceAccount permission to `get secrets`?

### Question 4
Why is the Service `ClusterIP` instead of directly exposing the application through a NodePort?

### Question 5
Why does the Deployment run two replicas?

### Question 6
If an attacker compromises one Pod, how do RBAC and the container security settings help reduce the blast radius?

### Question 7
Why is `automountServiceAccountToken` disabled?

---

# Part R — Cleanup

When you are finished:

```bash
kubectl delete namespace cloudorders
```

Verify:

```bash
kubectl get namespace cloudorders
```

Expected:

```text
Error from server (NotFound): namespaces "cloudorders" not found
```

Only delete the lab namespace. Do not delete or reset the kubeadm cluster.

---

# Completion checklist

You have completed the lab when all of these are true:

- [ ] kubeadm cluster/context verified
- [ ] Namespace created
- [ ] ConfigMap created and verified
- [ ] Secret created without exposing its value
- [ ] Dedicated ServiceAccount created
- [ ] Role created
- [ ] RoleBinding created
- [ ] Deployment rolled out with 2 replicas
- [ ] ClusterIP Service created
- [ ] Application reached with port-forward
- [ ] RBAC `yes/no` checks verified
- [ ] Pod security settings inspected
- [ ] Pod replacement/self-healing verified
- [ ] Cleanup completed
