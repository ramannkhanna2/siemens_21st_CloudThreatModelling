# Optional Security Challenge — NetworkPolicy

This is an extension, not part of the core lab.

## Objective

Restrict ingress to the application Pods so that traffic is allowed only from Pods carrying the label:

```text
access=cloudorders
```

## Important prerequisite

NetworkPolicy enforcement depends on the CNI installed in the kubeadm cluster. Check with the instructor before using this challenge.

You can inspect the cluster's CNI with:

```bash
kubectl get pods -A | grep -Ei 'calico|cilium|flannel|canal|antrea'
```

## Challenge

Create a NetworkPolicy in `cloudorders` that selects:

```yaml
app: cloudorders
```

and allows TCP/8080 ingress only from a Pod with:

```yaml
access: cloudorders
```

Do not add the answer immediately. Have participants consult Kubernetes NetworkPolicy documentation and test both an allowed and denied source.
