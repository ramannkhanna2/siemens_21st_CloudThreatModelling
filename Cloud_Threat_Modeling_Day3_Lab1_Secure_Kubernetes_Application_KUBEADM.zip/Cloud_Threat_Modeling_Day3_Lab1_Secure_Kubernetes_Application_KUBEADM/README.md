# Day 3 Lab 1 — Deploy a Secure Application on an Existing kubeadm Kubernetes Cluster

This lab is aligned to the Day 3 TOC objective:
- Deploy an Application
- Configure ConfigMaps
- Configure Secrets
- Create a Service
- Apply RBAC
- Verify Deployment

## Environment

This version is designed for an **existing kubeadm-based Kubernetes cluster**. It does **not** use Minikube, Docker Desktop Kubernetes, or `minikube` commands.

Participants only need:
- access to the existing cluster through `kubectl`
- a working kubeconfig/context
- permission to create resources in the lab namespace
- internet access from Kubernetes worker nodes to pull the public container image, unless the image is already available in the cluster's registry/cache

## Before starting

Run:

```bash
kubectl config current-context
kubectl cluster-info
kubectl get nodes -o wide
```

Every node required for scheduling should show `Ready`.

Do **not** run `kubeadm init`, `kubeadm join`, `kubeadm reset`, or change cluster networking for this lab.

## Application image

To keep the lab self-contained on an existing kubeadm cluster, participants use the verified NGINX Inc. unprivileged image rather than building a local image. The image is designed to run NGINX as an unprivileged user and listens on port 8080 by default.

Image used by the lab:

`nginxinc/nginx-unprivileged:1.31-alpine3.24`

The lab does not require Docker or a container build on the participant machine.

## Lab architecture

Participant -> kubectl -> Kubernetes API
                              |
                              v
                       cloudorders namespace
                              |
                       Deployment (2 replicas)
                              |
                         ClusterIP Service
                              |
                    +---------+---------+
                    |                   |
                  Pod 1               Pod 2
                    |                   |
              NGINX unprivileged  NGINX unprivileged
                    |
             +------+------+
             |             |
         ConfigMap       Secret
       (non-secret)     (sensitive)
             |
        ServiceAccount
             |
          RoleBinding
             |
             Role

The workload has a dedicated ServiceAccount, a namespaced Role/RoleBinding, and a restricted-style container securityContext. Because the application does not need to call the Kubernetes API, ServiceAccount token automounting is disabled.

## Files

- `k8s/00-namespace.yaml` — namespace with Pod Security labels
- `k8s/01-configmap.yaml` — non-confidential application configuration + training page
- `k8s/02-secret.yaml` — training-only secret mounted into the Pod
- `k8s/03-serviceaccount.yaml` — dedicated workload identity
- `k8s/04-role.yaml` — least-privilege Role
- `k8s/05-rolebinding.yaml` — binds the Role to the ServiceAccount
- `k8s/06-deployment.yaml` — 2-replica secure Deployment
- `k8s/07-service.yaml` — internal ClusterIP Service
- `optional-security-challenge.md` — optional NetworkPolicy/security exercise
- `PARTICIPANT_HANDOUT.md` — complete self-guided instructions
- `INSTRUCTOR_NOTES.md` — instructor guide and troubleshooting

## Shared-cluster note

If many participants share one kubeadm cluster, do not let everyone use the same namespace. Give each participant a unique namespace such as `cloudorders-rk01`, then either:
1. replace `cloudorders` with that namespace in the YAML files, or
2. have the instructor provide a pre-edited copy of the manifest folder for each participant.

The cleanest classroom setup is one namespace per participant.

## Main learning outcome

Participants should be able to explain and demonstrate:

Container/workload
    -> Deployment
    -> Service
    -> ConfigMap / Secret
    -> ServiceAccount
    -> RBAC
    -> securityContext

The security story is least privilege and reduced blast radius: the workload gets only the Kubernetes identity and permissions it needs, while the container itself runs without root privileges or privilege escalation.
