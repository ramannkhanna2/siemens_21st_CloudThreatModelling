# Instructor Solution Patch

## 1. Fix BOLA

Change `/orders/<order_id>` to:

```python
@app.get("/orders/<int:order_id>")
@require_auth
def get_order(order_id):
    order = ORDERS.get(order_id)
    if not order:
        return jsonify(error="order_not_found"), 404

    if (
        order["owner"] != g.current_user["sub"]
        and g.current_user["role"] != "admin"
    ):
        return jsonify(error="forbidden"), 403

    return jsonify(order)
```

## 2. Fix BFLA

Change `/admin/orders` to:

```python
@app.get("/admin/orders")
@require_auth
def admin_orders():
    if g.current_user["role"] != "admin":
        return jsonify(error="forbidden"), 403

    return jsonify(list(ORDERS.values()))
```

## 3. Add Flask-Limiter

Imports:

```python
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
```

After `app = Flask(__name__)`:

```python
limiter = Limiter(
    get_remote_address,
    app=app,
    storage_uri="memory://",
)
```

Rate-limit endpoints:

```python
@app.post("/login")
@limiter.limit("5 per minute")
def login():
    ...
```

```python
@app.get("/orders/<int:order_id>")
@limiter.limit("20 per minute")
@require_auth
def get_order(order_id):
    ...
```

```python
@app.get("/admin/orders")
@limiter.limit("10 per minute")
@require_auth
def admin_orders():
    ...
```

## Optional JSON 429 handler

```python
@app.errorhandler(429)
def rate_limit_handler(_error):
    return jsonify(error="rate_limit_exceeded"), 429
```

## Production note

The lab uses `memory://` for simple local training. Flask-Limiter documents this as suitable for testing/development; production deployments should use an appropriate shared/persistent backend.
