import os
from datetime import datetime, timedelta, timezone
from functools import wraps

import jwt
from flask import Flask, g, jsonify, request

JWT_SECRET = os.environ.get("JWT_SECRET")
if not JWT_SECRET:
    raise RuntimeError("JWT_SECRET environment variable is required")

JWT_ALGORITHM = "HS256"
JWT_ISSUER = "cloudorders-auth"
JWT_AUDIENCE = "cloudorders-api"

app = Flask(__name__)

USERS = {
    "alice": {"password": "AlicePass123!", "role": "user"},
    "bob": {"password": "BobPass123!", "role": "user"},
    "admin": {"password": "AdminPass123!", "role": "admin"},
}

ORDERS = {
    1001: {"id": 1001, "owner": "alice", "item": "Laptop", "amount": 1200},
    1002: {"id": 1002, "owner": "bob", "item": "Monitor", "amount": 450},
    1003: {"id": 1003, "owner": "alice", "item": "Keyboard", "amount": 120},
}


def create_access_token(username, expires_minutes=15):
    now = datetime.now(timezone.utc)
    payload = {
        "sub": username,
        "role": USERS[username]["role"],
        "iss": JWT_ISSUER,
        "aud": JWT_AUDIENCE,
        "iat": now,
        "exp": now + timedelta(minutes=expires_minutes),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_access_token(token):
    return jwt.decode(
        token,
        JWT_SECRET,
        algorithms=[JWT_ALGORITHM],
        issuer=JWT_ISSUER,
        audience=JWT_AUDIENCE,
        options={"require": ["sub", "role", "iss", "aud", "iat", "exp"]},
    )


def require_auth(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        header = request.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            return jsonify(error="missing_bearer_token"), 401

        token = header[len("Bearer "):].strip()
        if not token:
            return jsonify(error="missing_bearer_token"), 401

        try:
            claims = decode_access_token(token)
        except jwt.ExpiredSignatureError:
            return jsonify(error="token_expired"), 401
        except jwt.InvalidTokenError:
            return jsonify(error="invalid_token"), 401

        g.current_user = claims
        return view(*args, **kwargs)

    return wrapper


@app.get("/health")
def health():
    return jsonify(status="ok")


@app.post("/login")
def login():
    body = request.get_json(silent=True) or {}
    username = body.get("username")
    password = body.get("password")

    user = USERS.get(username)
    if not user or password != user["password"]:
        return jsonify(error="invalid_credentials"), 401

    return jsonify(
        access_token=create_access_token(username),
        token_type="Bearer",
        expires_in=900,
    )


@app.get("/me")
@require_auth
def me():
    return jsonify(
        username=g.current_user["sub"],
        role=g.current_user["role"],
    )


@app.get("/orders/<int:order_id>")
@require_auth
def get_order(order_id):
    order = ORDERS.get(order_id)
    if not order:
        return jsonify(error="order_not_found"), 404

    # INTENTIONALLY VULNERABLE FOR THE LAB:
    # Authentication is checked but ownership is not checked.
    return jsonify(order)


@app.get("/admin/orders")
@require_auth
def admin_orders():
    # INTENTIONALLY VULNERABLE FOR THE LAB:
    # Authentication is checked but role authorization is not checked.
    return jsonify(list(ORDERS.values()))


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
