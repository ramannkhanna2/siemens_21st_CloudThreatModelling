import os
from datetime import datetime, timedelta, timezone
import jwt

secret = os.environ.get("JWT_SECRET")
if not secret:
    raise SystemExit("Set JWT_SECRET before running this script.")

now = datetime.now(timezone.utc)
payload = {
    "sub": "alice",
    "role": "user",
    "iss": "cloudorders-auth",
    "aud": "cloudorders-api",
    "iat": now - timedelta(hours=1),
    "exp": now - timedelta(minutes=5),
}
print(jwt.encode(payload, secret, algorithm="HS256"))
