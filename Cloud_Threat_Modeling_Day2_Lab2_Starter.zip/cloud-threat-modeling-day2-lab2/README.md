# Day 2 — Lab 2: Secure and Attack-Test a REST API

## Learning objectives
- Configure and test JWT authentication
- Verify missing/invalid/expired/valid tokens
- Identify and fix Broken Object Level Authorization (BOLA)
- Identify and fix Broken Function Level Authorization (BFLA)
- Add rate limiting and verify HTTP 429
- Run security regression tests

## Prerequisites
- Python 3.10+
- curl (Git Bash/Windows curl.exe is fine)
- VS Code or another editor
- No cloud account required

## Training-only credentials
alice / AlicePass123!
bob / BobPass123!
admin / AdminPass123!

Never reuse these credentials.

## Setup
Create and activate a virtual environment.

Git Bash:
```bash
python -m venv .venv
source .venv/Scripts/activate
```

PowerShell:
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

Install:
```bash
python -m pip install -r requirements.txt
```

Set JWT secret.

Git Bash:
```bash
export JWT_SECRET='lab-only-secret-change-this-to-a-long-random-value-123456789'
```

PowerShell:
```powershell
$env:JWT_SECRET="lab-only-secret-change-this-to-a-long-random-value-123456789"
```

Run:
```bash
python -m app.app
```

API:
http://127.0.0.1:5000
