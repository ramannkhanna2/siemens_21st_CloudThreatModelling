# Day 2 — Lab 2
# Secure and Attack-Test a REST API

## Scenario
CloudOrders provides a REST API for customers and administrators.

Endpoints:

```text
POST /login
GET  /me
GET  /orders/{id}
GET  /admin/orders
```

The starter app contains intentional authorization weaknesses.

## A. Setup

Create/activate a virtual environment and install requirements:

```bash
python -m pip install -r requirements.txt
```

Set `JWT_SECRET`.

Git Bash:
```bash
export JWT_SECRET='lab-only-secret-change-this-to-a-long-random-value-123456789'
```

PowerShell:
```powershell
$env:JWT_SECRET="lab-only-secret-change-this-to-a-long-random-value-123456789"
```

Start:
```bash
python -m app.app
```

## B. Verify health

```bash
curl http://127.0.0.1:5000/health
```

Expected:
```json
{"status":"ok"}
```

## C. Login

Git Bash:
```bash
curl -X POST http://127.0.0.1:5000/login   -H "Content-Type: application/json"   -d '{"username":"alice","password":"AlicePass123!"}'
```

Copy the token into:

```bash
export TOKEN="PASTE_TOKEN_HERE"
```

PowerShell:
```powershell
$env:TOKEN="PASTE_TOKEN_HERE"
```

## D. Authentication tests

Valid token:
```bash
curl -i http://127.0.0.1:5000/me   -H "Authorization: Bearer $TOKEN"
```
Expected: `200`.

Missing token:
```bash
curl -i http://127.0.0.1:5000/me
```
Expected: `401`.

Invalid token:
```bash
curl -i http://127.0.0.1:5000/me   -H "Authorization: Bearer not.a.real.token"
```
Expected: `401`.

Expired token:
```bash
python scripts/make_expired_token.py
```
Copy the result, then:
```bash
curl -i http://127.0.0.1:5000/me   -H "Authorization: Bearer PASTE_EXPIRED_TOKEN"
```
Expected: `401`.

## E. Demonstrate BOLA

Alice's own order:
```bash
curl -i http://127.0.0.1:5000/orders/1001   -H "Authorization: Bearer $TOKEN"
```
Expected initially: `200`.

Alice requests Bob's order:
```bash
curl -i http://127.0.0.1:5000/orders/1002   -H "Authorization: Bearer $TOKEN"
```

If Bob's order is returned, the API is vulnerable to Broken Object Level Authorization (BOLA).

Fix it by checking that the requested object belongs to the authenticated user, allowing the admin role where appropriate.

Target:
```text
Alice -> /orders/1001 = 200
Alice -> /orders/1002 = 403
```

## F. Demonstrate BFLA

With Alice's token:

```bash
curl -i http://127.0.0.1:5000/admin/orders   -H "Authorization: Bearer $TOKEN"
```

Initially, the endpoint returns data because authentication exists but function-level authorization is missing.

Fix it so only role `admin` can access it.

Login as admin:

```bash
curl -X POST http://127.0.0.1:5000/login   -H "Content-Type: application/json"   -d '{"username":"admin","password":"AdminPass123!"}'
```

Set:
```bash
export ADMIN_TOKEN="PASTE_ADMIN_TOKEN_HERE"
```

Target:
```text
Alice -> /admin/orders = 403
Admin -> /admin/orders = 200
```

## G. Add rate limiting

Install is already covered by requirements.

In `app/app.py` add:

```python
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
```

Then:

```python
limiter = Limiter(
    get_remote_address,
    app=app,
    storage_uri="memory://",
)
```

Rate-limit login:

```python
@app.post("/login")
@limiter.limit("5 per minute")
def login():
```

Rate-limit orders:

```python
@app.get("/orders/<int:order_id>")
@limiter.limit("20 per minute")
@require_auth
def get_order(order_id):
```

Rate-limit admin:

```python
@app.get("/admin/orders")
@limiter.limit("10 per minute")
@require_auth
def admin_orders():
```

## H. Verify 429

Git Bash:
```bash
for i in {1..25}; do
  curl -s -o /dev/null -w "%{http_code}
"     http://127.0.0.1:5000/orders/1001     -H "Authorization: Bearer $TOKEN"
done
```

You should eventually see:

```text
429
```

A 429 means the rate limit was exceeded.

## I. Regression tests

Run:

```bash
python -m pytest -q
```

Target:
All supplied tests pass.

## Final security matrix

```text
Missing token      -> 401
Invalid token      -> 401
Expired token      -> 401
Valid token        -> 200
Own object         -> 200
Other user's object-> 403
Non-admin function -> 403
Admin function     -> 200
Excessive requests -> 429
```

## Security questions
1. Why is authentication not enough to prevent BOLA?
2. What is the difference between BOLA and BFLA?
3. Why should the server not trust a client-supplied owner/customer ID?
4. Why should token validation pin the allowed algorithm?
5. What problem does rate limiting address?
6. Is `memory://` suitable for a distributed production API?
