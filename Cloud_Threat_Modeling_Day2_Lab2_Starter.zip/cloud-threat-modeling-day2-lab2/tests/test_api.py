import os
from datetime import datetime, timedelta, timezone

import jwt

os.environ.setdefault(
    "JWT_SECRET",
    "lab-only-secret-change-this-to-a-long-random-value-123456789",
)

from app.app import (
    JWT_ALGORITHM,
    JWT_AUDIENCE,
    JWT_ISSUER,
    app,
    create_access_token,
)


def login(client, username, password):
    return client.post(
        "/login",
        json={"username": username, "password": password},
    )


def test_login_success():
    client = app.test_client()
    response = login(client, "alice", "AlicePass123!")
    assert response.status_code == 200
    assert "access_token" in response.json


def test_missing_token_is_401():
    client = app.test_client()
    response = client.get("/me")
    assert response.status_code == 401


def test_invalid_token_is_401():
    client = app.test_client()
    response = client.get(
        "/me",
        headers={"Authorization": "Bearer not.a.real.token"},
    )
    assert response.status_code == 401


def test_expired_token_is_401():
    now = datetime.now(timezone.utc)
    token = jwt.encode(
        {
            "sub": "alice",
            "role": "user",
            "iss": JWT_ISSUER,
            "aud": JWT_AUDIENCE,
            "iat": now - timedelta(hours=1),
            "exp": now - timedelta(minutes=5),
        },
        os.environ["JWT_SECRET"],
        algorithm=JWT_ALGORITHM,
    )

    client = app.test_client()
    response = client.get(
        "/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 401


def test_valid_token_is_authorized():
    client = app.test_client()
    token = create_access_token("alice")
    response = client.get(
        "/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    assert response.json["username"] == "alice"


def test_bola_is_blocked_after_fix():
    client = app.test_client()
    token = create_access_token("alice")
    response = client.get(
        "/orders/1002",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 403


def test_non_admin_cannot_use_admin_function():
    client = app.test_client()
    token = create_access_token("alice")
    response = client.get(
        "/admin/orders",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 403


def test_admin_can_use_admin_function():
    client = app.test_client()
    token = create_access_token("admin")
    response = client.get(
        "/admin/orders",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    assert len(response.json) == 3
